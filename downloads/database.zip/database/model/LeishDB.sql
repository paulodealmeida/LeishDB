/*
Navicat MySQL Data Transfer

Source Server         : LeishDBLW
Source Server Version : 50621
Source Host           : mysql02.leishdb.hospedagemdesites.ws:3306
Source Database       : leishdb1

Target Server Type    : MYSQL
Target Server Version : 50621
File Encoding         : 65001

Date: 2016-05-21 17:58:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for chromossomes
-- ----------------------------
DROP TABLE IF EXISTS `chromossomes`;
CREATE TABLE `chromossomes` (
  `idchromosome` int(11) NOT NULL AUTO_INCREMENT,
  `gbid` varchar(255) DEFAULT NULL,
  `organismid` int(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `sequence` longtext,
  `size` int(11) DEFAULT NULL,
  PRIMARY KEY (`idchromosome`),
  KEY `fk_organism_chromossome` (`organismid`),
  CONSTRAINT `fk_organism_chromossome` FOREIGN KEY (`organismid`) REFERENCES `organisms` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for crossreference
-- ----------------------------
DROP TABLE IF EXISTS `crossreference`;
CREATE TABLE `crossreference` (
  `proteinid` varchar(255) NOT NULL,
  `databaseid` bigint(20) NOT NULL,
  `referenceid` varchar(255) NOT NULL,
  PRIMARY KEY (`proteinid`,`databaseid`),
  KEY `fk_databases_crossreference_idx` (`databaseid`),
  CONSTRAINT `fk_protein_crossreference` FOREIGN KEY (`proteinid`) REFERENCES `proteins` (`proteinid`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for databases
-- ----------------------------
DROP TABLE IF EXISTS `databases`;
CREATE TABLE `databases` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `url` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `urlbyintegration` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for geneontology
-- ----------------------------
DROP TABLE IF EXISTS `geneontology`;
CREATE TABLE `geneontology` (
  `goid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `description` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `type` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`goid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for genes
-- ----------------------------
DROP TABLE IF EXISTS `genes`;
CREATE TABLE `genes` (
  `id` int(65) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `startcodonlocal` int(65) DEFAULT NULL,
  `endcodonlocal` int(65) DEFAULT NULL,
  `startgenomelocal` int(65) DEFAULT NULL,
  `endgenomelocal` int(65) DEFAULT NULL,
  `frame` int(65) DEFAULT NULL,
  `score` int(65) DEFAULT NULL,
  `genomeid` int(65) DEFAULT NULL,
  `size` int(65) DEFAULT NULL,
  `proteinid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_proteinid_genes_idx` (`proteinid`),
  KEY `fk_chromosomes_genes_idx` (`genomeid`)
) ENGINE=InnoDB AUTO_INCREMENT=30749 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for ncrna
-- ----------------------------
DROP TABLE IF EXISTS `ncrna`;
CREATE TABLE `ncrna` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `genomeid` int(11) DEFAULT NULL,
  `family` varchar(255) DEFAULT NULL,
  `score` float DEFAULT NULL,
  `evalue` float DEFAULT NULL,
  `start_location` int(11) DEFAULT NULL,
  `end_location` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `fk_ncrna_chromosomes_idx` (`genomeid`)
) ENGINE=InnoDB AUTO_INCREMENT=1910 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for organisms
-- ----------------------------
DROP TABLE IF EXISTS `organisms`;
CREATE TABLE `organisms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organism` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for proteins
-- ----------------------------
DROP TABLE IF EXISTS `proteins`;
CREATE TABLE `proteins` (
  `proteinid` varchar(255) NOT NULL,
  `entryname` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `proteinname` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `genename` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `organism` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `length` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `taxonomiclineage` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `proteinfamily` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`proteinid`),
  KEY `proteinid` (`proteinid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for proteinsgo
-- ----------------------------
DROP TABLE IF EXISTS `proteinsgo`;
CREATE TABLE `proteinsgo` (
  `proteinid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `goid` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`proteinid`,`goid`),
  KEY `fk_proteinsgo_goid_idx` (`goid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for publications
-- ----------------------------
DROP TABLE IF EXISTS `publications`;
CREATE TABLE `publications` (
  `proteinid` varchar(255) NOT NULL,
  `pubmedid` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
